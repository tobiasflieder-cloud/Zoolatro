
document.documentElement.lang='de';
